package test.totallesson.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class StringUils {

	public static List<String> readFileResouceByLine(String fileNameResouce) {
		StringUils stringUils = new StringUils();
		File file = new File(stringUils.getClass().getClassLoader().getResource(fileNameResouce).getFile());
		return readFileByLine(file);
	}

	public static List<String> readFileByLine(File file) {
		List<String> listString = new ArrayList<String>();
		String pathFile = file.getAbsolutePath();
		String valueuft8 = pathFile.trim().replaceAll("%20", " ");
		try (BufferedReader br = Files.newBufferedReader(Paths.get(valueuft8))) {
			// read line by line
			String line;
			while ((line = br.readLine()) != null) {
				if (!line.trim().isEmpty()) {
					listString.add(line);
				}
			}
		} catch (IOException e) {
			System.err.format("IOException: %s%n", e);
		}
		return listString;
	}

	public static List<String> readFileByLineNew(File file) {
		String pathFile = file.getAbsolutePath();
		String valueuft8 = pathFile.trim().replaceAll("%20", " ");
		return readFile(valueuft8);
	}
	
	public static List<String> readFile(String pathFile) {
		List<String> listString = new ArrayList<String>();
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(pathFile));
			String line = reader.readLine();
			if(!line.trim().isEmpty() && line != null) {
				listString.add(line);
			}
			while (line != null) {
				line = reader.readLine();
				if(line != null) {
					listString.add(line);
				}
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return listString;
	}
	
	
}
