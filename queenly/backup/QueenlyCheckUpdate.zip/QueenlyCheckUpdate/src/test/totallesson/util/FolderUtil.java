package test.totallesson.util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class FolderUtil {

	/**
	 * @param rootFolder
	 * @return totalFile infolder
	 */
	public static List<File> getTotalFilePHP(String rootFolder) {
		List<File> result = new ArrayList<File>();
		try {
			File file = new File(rootFolder);
			File[] files = file.listFiles();
			for (File file2 : files) {
				File[] fileElement = file2.listFiles();
				for (int i = 0; i < fileElement.length; i++) {
					result.add(fileElement[i]);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
}
