package test.totallesson;

import java.util.ArrayList;
import java.util.List;

import test.totallesson.lesson.Lesson;

public class VideoChecker {
	List<Lesson> lessonOk = new ArrayList<Lesson>();
	List<String> fileNothHasVideo = new ArrayList<String>();
	List<String> fileVideoDuplicate = new ArrayList<String>();

	public List<Lesson> getLessonOk() {
		return lessonOk;
	}

	public void setLessonOk(List<Lesson> lessonOk) {
		this.lessonOk = lessonOk;
	}

	public List<String> getFileNothHasVideo() {
		return fileNothHasVideo;
	}

	public void setFileNothHasVideo(List<String> fileNothHasVideo) {
		this.fileNothHasVideo = fileNothHasVideo;
	}

	public List<String> getFileVideoDuplicate() {
		return fileVideoDuplicate;
	}

	public void setFileVideoDuplicate(List<String> fileVideoDuplicate) {
		this.fileVideoDuplicate = fileVideoDuplicate;
	}

}
