package test.totallesson;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import test.totallesson.lesson.Lesson;
import test.totallesson.util.FolderUtil;
import test.totallesson.util.StringUils;

public class MainCheck {

	private static final String FILE_PAGES = "E:\\Workspace\\Laravel Projects\\CorsetaAdemy\\queenly\\resources\\views\\layouts\\pages";
	private static final String LESSON_TEXT = "lesson.txt";
	private static final String HOST_VIDEO = "https://player.vimeo.com";

	public static void main(String[] args) {

		int totalLesson = getTotalLesson();
		System.out.println("Total lesson: " + totalLesson);

		List<File> listPage = FolderUtil.getTotalFilePHP(FILE_PAGES);
		int totalPage = listPage.size();
		System.out.println("Total file:" + totalPage);

		VideoChecker videoChecker = getAllLinkVideo(listPage, HOST_VIDEO);
		List<Lesson> lessonOk = videoChecker.getLessonOk();
		List<String> nothasVideo = videoChecker.getFileNothHasVideo();
		int totalVideoOK = lessonOk.size();
		System.out.println("Total video find Ok :" + totalVideoOK);

		System.out.println("File miss video: " + (nothasVideo.size()));
		// return miss total
		System.out.println("Missing lesson: " + (totalLesson - totalPage));
		
		//out lesson video duplicate Link
		List<Lesson> lessonsDuplicate = getLessonDuplicateVideo(lessonOk);
		System.out.println("Total lesson duplicate video is: " + lessonsDuplicate.size());
		for (int j = 0; j < lessonsDuplicate.size(); j++) {
			System.out.println(j + "." + lessonsDuplicate.get(j).getFolderPath());
		}

	}

	/**
	 * return total lesson in menu remove parent menu
	 */
	private static int getTotalLesson() {
		// copy menu lesson of corsetacademy.net
		List<String> lines = StringUils.readFileResouceByLine(LESSON_TEXT);
		int totalLesson = 0;
		for (String line : lines) {
			// find (14) => 14
			int beginIndex = -1;
			int endIndex = -1;
			beginIndex = line.indexOf('(');
			endIndex = line.indexOf(')', beginIndex);
			String item = line.substring(beginIndex + 1, endIndex);
			int lessionItem = Integer.parseInt(item);
			totalLesson += lessionItem;
		}
		return totalLesson;
	}

	private static VideoChecker getAllLinkVideo(List<File> listPage, String subString) {
		VideoChecker videoChecker = new VideoChecker();
		List<Lesson> lessonOk = new ArrayList<Lesson>();
		List<String> videos = new ArrayList<String>();
		try {
			for (File file : listPage) {
				boolean fileHasVideo = false;
				List<String> lines = StringUils.readFileByLine(file);
				if (lines.size() <= 0) {
					lines = StringUils.readFileByLineNew(file);
				}
				for (String line : lines) {
					if (line == null || line.trim().isEmpty()) {
						continue;
					}
					int position = line.indexOf(subString);
					boolean hasString = position == -1 ? false : true;
					if (!hasString) {
						continue;
					} else {
						int firstSrc = line.lastIndexOf('"', position);
						int lastSrc = line.indexOf('"', position);
						String src = line.substring(firstSrc + 1, lastSrc);
						Lesson lesson = new Lesson();
						lesson.setFolderPath(file.getAbsolutePath());
						lesson.setVideoPath(src);
						lessonOk.add(lesson);
						videos.add(src);
						fileHasVideo = true;
						break;
					}
				}
				if (!fileHasVideo) {
					videoChecker.getFileNothHasVideo().add(file.getAbsolutePath());
				}
			}
		} catch (Exception e) {
			// e.printStackTrace();
		}
		videoChecker.setLessonOk(lessonOk);
		return videoChecker;
	}

	private static List<Lesson> getLessonDuplicateVideo(List<Lesson> lessonOk) {
		Set<Lesson> inpputLess = new HashSet<Lesson>(lessonOk);
		if (inpputLess.size() < lessonOk.size()) {
			System.out.println("Input 'lessonOk' duplicate");
		}
		Set<String> videoPaths = new HashSet<String>();
		List<Lesson> lessonVideoDuplicate = new ArrayList<Lesson>();
		for (int i = 0; i < lessonOk.size(); i++) {
			Lesson lesson = lessonOk.get(i);
			String videoPath = lesson.getVideoPath();
			int sizeBeforeAdd = videoPaths.size();
			videoPaths.add(videoPath);
			int sizeAfterAdd = videoPaths.size();
			boolean isDuplicate = sizeAfterAdd == sizeBeforeAdd ? true : false;
			if(isDuplicate) {
				Lesson lessonDuplicate = new Lesson();
				lessonDuplicate.setFolderPath(lesson.getFolderPath());
				lessonDuplicate.setVideoPath(lesson.getVideoPath());
				lessonVideoDuplicate.add(lessonDuplicate);
			}
		}
		return lessonVideoDuplicate;
	}

}