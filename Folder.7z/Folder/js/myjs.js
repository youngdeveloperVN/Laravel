(function ($) {
  $(document).ready(function () {
    uploadImage()
    resetButton()
    function uploadImage() {
      var button = $('.images .pic')
      var uploader = $("input[name='photo[]']")
      var images = $('.images')
      
      button.on('click', function () {
        uploader.click()
      })
      
      uploader.on('change', function () {
		  reset();
		  for(var i = 0; i < uploader[0].files.length; i++){
			  var reader = new FileReader()
			  reader.onload = function(event) {
				images.prepend('<div title="'+uploader[0].files[i].name+'" class="img" style="background-image: url(\'' + event.target.result + '\');" rel="'+ event.target.result  +'"><span>remove</span></div>')
			  }
			  reader.readAsDataURL(uploader[0].files[i])
		  }
       })
      
      images.on('click', '.img', function () {
        $(this).remove()
      })
    }
    
   
    
    function resetButton() {
      var resetbtn = $('#reset')
      resetbtn.on('click', function () {
        reset()
      })
    }
    
    function reset() {
      var images = $('.images .img')
	 var newFileList = Array.from(event.target.files);
      for(var i = 0; i < images.length; i++) {
        $(images)[i].remove()
      }
    }
  })
})(jQuery)